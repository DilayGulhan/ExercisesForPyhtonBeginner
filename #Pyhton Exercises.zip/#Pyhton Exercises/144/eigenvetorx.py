from this import d
from tkinter import E


x1 = float(input("Enter x1:"))
x2 = float(input("Enter x2:"))
x3 = float(input("Enter x3:"))

a = (-9/2) * x1 + (-4) * x2 + (-1)*x3 -77/24
b = (2) * x1 + (3/2) * x2 + (1/2)*x3 + 29/12
c = (6) * x1 + (6) * x2 + (1)*x3 + 1/2 
print(a)
print(b)
print(c)

d = -x1 -10/4
e = -x2 
f = -x3 - 2 
print(d)
print(e)
print(f)
