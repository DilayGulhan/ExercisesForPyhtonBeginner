i=0
while(i<10):
    if (i==3 or i==5) :
        continue
print("i: ",i)
i=i+1
