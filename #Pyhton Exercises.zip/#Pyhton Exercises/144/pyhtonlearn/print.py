print("Hello Beril")
#String herhangi bir karakter 
#int tam sayı 
#float ondalık sayı 
name = input("Adın nedir?") #String algılar eğer int veya float istiyorsak belirtmek gerek 
age = int(input("Kaç yaşındasın?"))
gpa = float(input ("not ortalaman kaç ?"))


print("Benim adım " , age )
print("Benim yaşım " , age)
print("Gpa'm " , gpa)


