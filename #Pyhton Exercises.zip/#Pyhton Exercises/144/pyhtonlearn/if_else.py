number = int(input("Enter a number"))

if(number> 15):
    print("number is more than 15") #birden fazla if veya elif statement'ı kullanabiliriz.
    #algoritma baştan sıra sıra okuyor eğer if statement'ı yanlışsa diğer statementa yani bu örnekte 
    # elife geçiyor. Eğer hiçbiri tutmazsa else statement'ı çalışıyor.

if(number ==18): #birden fazla if örneği 
    print("this number is  18 ")

elif(number < 15):
    print("number is less than 15")

else:
    print("please enter a valid number")


## == eşittir demek
## != eşit değildir demek 
## >, < ,<= ,>= 





