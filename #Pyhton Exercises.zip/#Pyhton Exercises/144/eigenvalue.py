from cmath import e
from tkinter import E


x1 = float(input("Enter x1"))
x2 = float(input("Enter x2"))
x3 = float(input("Enter x3"))

a = ((321/5) *x1) + ((64/5)*x2) + ((88/5)*x3) -532/5
b = (-156*x1 )+ (-31*x2) + ((-216/5)* x3) + 1316/5
c = (-120*x1 )+(-24*x2) + ((-163/5)*x3) + 1008/5
print (a)
print(b)
print(c)

d = 1/3 * 1/5 * (3 * x1 -5) + 5/3
e = 1/5 * (x2-1) +1 
f = 1/5* 1/3* (3*x3 + 2) -2/3
print (d)
print(e)
print(f)

