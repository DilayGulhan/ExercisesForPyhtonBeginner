#Write  a  program  that  will  ask  the  user  to  enter  the  amount  of  a  purchase. 
#The  program should then compute the state and county sales tax. Assume the state sales tax is 5 percent and 
#the county sales tax is 2.5 percent. The program should display the amount of the pur-chase, the state sales tax, 
#the county sales tax, the total sales tax, and the total of the sale (which is the sum of the amount of
#  #purchase plus the total sales tax).
# Hint: Use the value 0.025 to represent 2.5 percent, and 0.05 to represent 5 percent.
#This time with using functions :

def main():
    amount = float(input("Enter the amount of the purchase"))
    get_state_sale(amount)
    county_sale(amount)
    print (county_sale(amount) + get_state_sale(amount))

def get_state_sale(x):
        state_sale = x * 0.025
        return state_sale
def county_sale(y):
    county_sale = y * 0.05
    return county_sale

main()

        

