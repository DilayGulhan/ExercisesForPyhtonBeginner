#Write a program that asks the user to enter the monthly costs 
# for the following expenses incurred from operating his or her automobile: loan payment, insurance, gas , oil , tires, and maintenance.
#The program should then display the total monthly cost of these expenses, 
# and the total annual cost of these expenses

def main() :
    print(month_sum() )
    annual_sum()

def month_sum():
    loan_payment = float(input("Enter the loan payment cost"))
    insurance = float(input("Enter the insurance cost"))  
    gas = float(input("Enter the gas cost "))
    oil = float(input("Enter the oil cost "))
    tires = float(input("Enter the tires cost "))
    maintenance= float(input("Enter the maintenance cost"))  
    total_month = loan_payment + insurance + gas + oil + tires + maintenance
    return total_month

def annual_sum():
    for i in range(3):
        annual = 0
        month_sum()
        annual = annual + total_month
    print("The annual is" , annual)
main()

 


