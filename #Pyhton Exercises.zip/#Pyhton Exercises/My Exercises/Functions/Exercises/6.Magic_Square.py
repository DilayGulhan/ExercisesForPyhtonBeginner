def main(list):
    diagonall1 = 0
    diagonall2= 0
    for i in range(3):
        diagonall1 = list[i][i]
        diagonall2 = list[i][i]
    ws
