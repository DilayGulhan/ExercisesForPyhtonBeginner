#Many financial experts advise that property owners should insure their homes or buildings for
# at least 80 percent of the amount it would cost to replace the structure. 
# Write a program that asks the user to enter the replacement cost of a building and 
# then displays the minimum amount of the insurance he or she should buy for the property.

def main():
    replacement_cost = float(input("Enter the replacement cost of a building "))
    print("the minimum amount is " , minimum_amount(replacement_cost))

def minimum_amount(x):
    x = x* (80/100)
    return x #We used return in there because thats the function we produce
main()


