#Write a program that asks the user to enter a distance in kilometers,
# and then converts that distance to miles. The formula is : 
#miles = km * 0.6214
def main():
    km = int(input("Enter the distance"))
    miles(km)

def miles(a):
    mile = a * 0.6214
    print(mile)

main()