#This porgram calculates the length of a right 
# triangle's hypotenuse

import math
def main():
    a = int(input("Enter the length of the a side: "))
    b = int(input("Enter the length of the b side: "))
    c = math.hypot(a ,b )
    print(c)
   
main()