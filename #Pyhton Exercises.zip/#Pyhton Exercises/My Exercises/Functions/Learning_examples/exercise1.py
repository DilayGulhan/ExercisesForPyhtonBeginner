def dilay(rep , str):
    for i in range(rep):
        print(str)

dilay(5 , "and")

