#The following is used as a global constant 
# the contribution rate . 
CONTRUBUTION_RATE = 0.05

def main():
    gross_pay = float(input("Enter the  gross pay:"))
    bonus = float(input("Enter the amount of the bonuses "))
    show_pay_contrib(gross_pay) 
    show_bonus_contrib(bonus)

def show_pay_contrib(gross):
    contrib = gross * CONTRUBUTION_RATE
    print( contrib)

def show_bonus_contrib(bonus):
    contrib = bonus * CONTRUBUTION_RATE
    print(contrib)
main()
    