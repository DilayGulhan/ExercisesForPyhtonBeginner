s = " Bugün hava çok güzel"
print(s.split(" "))
print(s.split("a"))

