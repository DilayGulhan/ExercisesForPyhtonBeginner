#This program simulates 10 tosses of a coin.

import random

HEADS= 1
TAILS = 2
TOSSES = 10
def main():
    for toss in range(TOSSES):
        #simulate the coin toss.
        if random.randint(HEADS , TAILS) == HEADS:
            print("heads")
        else:
            print("tails")
        
main()
