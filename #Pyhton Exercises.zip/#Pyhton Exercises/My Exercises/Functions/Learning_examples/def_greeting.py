def greeting():
    print ("Good Morning")
    print( "Today we will learn about functions")
print("I'll call the greeting function ")
greeting()
