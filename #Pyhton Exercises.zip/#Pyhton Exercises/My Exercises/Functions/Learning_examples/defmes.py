def message():
    print("I am Arthur ")
    print("King of the Brtions.")

message()