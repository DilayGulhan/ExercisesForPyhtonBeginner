
def main():
    sales = get_monthly_sales()
    advanced_pay = get_advanced_pay()
    com_rate = get_com_rate(sales)
    pay = sales * com_rate - advanced_pay
    print("The pay is : "," \t", pay )
    
    if pay <0:
        print("The salesperson must reimburse")
        print("the company")


def get_monthly_sales():
    monthly_sales = float(input("Enter salesperson's monthly sales"))
    return monthly_sales #Do not forget to rreturn function 

def get_advanced_pay():
   advanced_pay = float(input("Enter advanced pay"))
   return advanced_pay 

def get_com_rate(sales): #If I don't write sales in there the program can't comprehend it 
    if sales < 10.000:
        rate = 0.10
    elif sales>= 10000 and sales <= 14999.99:
        rate = 0.12
    elif sales>= 15000 and sales <= 17999.99:
        rate = 0.14
    elif sales>= 18000 and sales <= 21999.99:
        rate = 0.16
    else:
        rate = 0.16
    return rate
main()
    
    
#Come back it again >>>>> !!!!!!!!!!!!!!!!






