import math 

def area(radius):
    return math.pi* radius**2

def circumferences(radius):
    return math.pi*2*radius
