import circle 
import rectangle 

AREA_CIRCLE_CHOICE = 1 
CIRCUMFERENCE_CHOICE = 2
AREA_RECTANGLE_CHOICE = 3
PERIMETER_RECTANGLE_CHOICE = 4
QUIT_CHOICE = 5 

def main():
    choice = 0

    

    