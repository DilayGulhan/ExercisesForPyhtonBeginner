def area (width , length):
    return width* length

def perimeter(width , length):
    return 2 * (width + length)