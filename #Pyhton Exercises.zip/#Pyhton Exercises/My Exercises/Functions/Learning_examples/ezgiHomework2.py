#firstly, you should ask the user which operation he or she would like to use.
#secondly, plain text and the shift amount should be taken by the user in the MAİN funtion.
#your program should not be case sensitive.
#program should run 2 times at least.

from re import X


operation = input("""Please choose one of the operations below:
a-Decryption
b-Ecryption
Note: Please only enter a or b""")
word_list = ["a","b", "c", "d" , "e" , "f", "g" , "h" , "i" , "k", "j" "l" , "m" , "n" , "o" ,"q" , "p" , "r", "s", "t", "u" , "w", "x" , "y" , "z" ]

if operation == "a":
    print("You choose to Decrypt")
    word_to_decrypt = input("Please enter the word that you want to decrypt")
    word_to_decrypt.split(" " )
    print(word_to_decrypt , end= "")


