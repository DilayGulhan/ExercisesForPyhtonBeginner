#Write a code that determines whether the number is prime or not 


def is_prime(n):
    for i in range(2 ,n):
        if n % i == 0 :
            return "False"
        else:
            return "True"
def main():
    number = int(input("Enter a number whether to check is prime or not"))
    if is_prime (number):
        print("the number is prime")
    else:
        print("the number isn't prime")


