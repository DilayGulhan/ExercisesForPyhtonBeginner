#This program uses the reurn value of a function. 

def main():
    #Get the user's age
    first_age = int(input("Enter your age:"))

    #Get the user's best friend's age  
    second_age = int(input("Enter your best friend's age")) 
    
    #Get the sum of both ages
    total = sum(first_age , second_age) 

    print("Together you are ", total , "years old")

#The sum function accepts two numeric arguments and 
# returns the sum of those arguments

def sum(num1, num2):
    result = num1 + num2
    return result  #We assign value to this function 
                   #Otherwise we just say do it to this function 

#Call the main function 
main()
