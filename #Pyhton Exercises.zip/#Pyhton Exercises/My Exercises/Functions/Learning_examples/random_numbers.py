#This program displays a random number 
# in the range of 1 through 10.
import random

def main():
    #Get a random number 
    number = random.randint(1 ,10)
    print("The number is:" , number)

main()