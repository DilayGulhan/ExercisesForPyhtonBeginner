import random
number = print(random.randrange(10))

number1 = print(random.randrange(5,10))

number2 = print(random.randrange(0,101,10))

number3 = print(random.random())

number4 = print(random.uniform(1.0 , 10.0))

