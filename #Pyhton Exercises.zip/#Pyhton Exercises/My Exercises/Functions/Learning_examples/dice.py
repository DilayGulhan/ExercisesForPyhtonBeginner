import random 


MAX = 6
MIN = 1
def main():
    enter = input("Press y to start the game")
    while enter == "y" : 
        print("Rolling the dice")
        print("Their values are")
        print(random.randint(MIN, MAX))
        print(random.randint(1, 6 ))
        enter = input("Press y to continiue the game")
main()
        
        