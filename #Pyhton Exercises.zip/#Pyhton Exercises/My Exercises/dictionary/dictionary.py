# Dictionary'nin indexleri taşıdığı anahtarlardır.a değeri, b değeri vs.
d = {"a": 5, "b": 3 , "c": 7 , "d":11 }

print(type(d))
print(len(d))

#Dictionary'de elemanlara erişim 

print(d["a"])
print(d.get("b"))

#Olmayan bir elemana erişim sağlamaya çalışmak hata verir.
#dictionary'deki anahtarların değerleri değiştirilebilir.
#Key'deki değerler aynı olabilir a:8 ,b:8 etc.
d.pop("a")
print(d)
del d["b"]
print(d)