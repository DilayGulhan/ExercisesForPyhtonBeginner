#Write a code that append two dictionary to one while do this 
# if there were two same component it will sum their values.
d1 = {"a":2 , "b":6 , "d":4  ,"g":1}
d2 = {"b":1 ,"c":4 , "d":3 , "e":2, "f":8 , "g":5}
d3 = {}
for item in d1:
    print(d1[item])

for item in d1:
    if item in d2:
        d3[item] = d1[item] + d2[item]
    else:
        d3[item] = d1[item]
for item in d2:
    if item not in d3:
        d3[item] = d2[item]
print(d3)
#Dictionary sıralı olmak zorunda değil




    