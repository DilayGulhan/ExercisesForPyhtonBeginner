def main():
    deck = create_deck()
    num_cards = int(input("How many cards should I deal"))
    deal_cards(deck , num_cards)

def create_deck():
    deck = {'Ace of Spades':1, '2 of Spades':2, '3 of Spades':3,
    '4 of Spades':4, '5 of Spades':5, '6 of Spades':6, 
    '7 of Spades':7, '8 of Spades':8, '9 of Spades':9,
    '10 of Spades':10, 'Jack of Spades':10,
    'Queen of Spades':10, 'King of Spades': 10}
    return deck

def deal_cards(deck,number):
    hand_value = 0 
    
    if number> len(deck):
        number = len(deck)

    for count in range(number):
        card, value = deck.popitem()
        print(card)
        hand_value += value

    print("The value of this hand:" , hand_value)

main()