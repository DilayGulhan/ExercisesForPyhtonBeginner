#Creating a dictionary
fruits = ["strawberry", "melon", "orange" , "pineapple"]
price =[12 ,13 ,14 ,15]
my_dictionary = {}
for i in range(len(fruits)) :
    keys = fruits[i]
    value = price[i]
    my_dictionary[keys] = value
print(my_dictionary)

#Retrieve value from dictionary 
print(my_dictionary["strawberry"])

#using in and not in operators to test value in dictionary
if "melon" in my_dictionary:
    print(my_dictionary["melon"])

else :
    print("the item hasn't found")

#adding elements to existing dictionary 
my_dictionary["watermelon"] = 22
print(my_dictionary)

#Deleting Elements
del my_dictionary["watermelon"]
print(my_dictionary)

#getting the number of the elements in the dictionary

num_items = len(my_dictionary)
print(num_items)
 
#Mixing data types in dictionary 
phonebook = {}
phonebook["Katie"] = 444-555
phonebook["Kylie"] = 844-545
phonebook["Leo"] = 345-238
print(phonebook)
# Using for loop in the dictionary 
for key in phonebook:
    print(key)


#METHODS 

#Clear
phonebook.clear()
print(phonebook)

#Get 
value = my_dictionary.get("melon" , "default")
print(value)
value2 = my_dictionary.get("watermelon" , "default")
print(value2)

#Items 
for key , value in my_dictionary.items():
    print(key , value)

#Keys 
for key in my_dictionary.keys():
    print(key )

#Values
for values in my_dictionary.values():
    print(values)

#Pop 
my_dictionary["watermelon"] = 18 
new = my_dictionary.pop("watermelon" , "default")
print(new)
#pop item 
ke , val = my_dictionary.popitem()
print(my_dictionary)
print(ke)





