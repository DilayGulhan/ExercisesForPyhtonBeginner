    # STEP 1
def read_genes(file_path):
    gene_dict = {}
    count = 0
    with open(file_path) as f:
        content = f.readlines()
        for i in content:
            if len(content) > count:
                if count % 2 == 0:
                    header = i
                    count += 1
                    continue
                if count % 2 == 1:
                    sequence = i
                    gene_dict[header] = sequence
                    count += 1
                    continue
    return gene_dict
    