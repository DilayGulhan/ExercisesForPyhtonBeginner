#This program uses a dictionary to keep friends names and birthdays.

#Globals for menu to choice 

LOOK_UP = 1 
ADD = 2 
CHANGE= 3 
DELETE = 4
QUIT = 5
 

def main():
    birthdays = {}

    choice = 0 

    while choice != QUIT :
        choice = get_menu_choice()

        if choice == LOOK_UP :
            look_up(birthdays)
        
        elif choice== ADD :
            add(birthdays)
        
        elif choice == CHANGE :
            change(birthdays)
        
        elif choice == DELETE :
            delete(birthdays)

def get_menu_choice():
   print()
   print("Friends and their birthdays")
   print("-----------")
   print("1.look up a birthday ")