phonebook = {'Chris':'555-1111', 'Joanne':'555−3333' , 'Katie':'555−2222'} 
for key in phonebook:
    print(key )
for key in phonebook:
    print(key , phonebook[key])
phonebook.keys()
print(phonebook) 