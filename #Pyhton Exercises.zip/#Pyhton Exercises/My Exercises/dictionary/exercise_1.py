
def freq_counter(my_list):
    
    result_dict = {}
    
    for item in my_list:
        if item not in result_dict:
            result_dict[item]= 1
        if item in result_dict:
            result_dict[item]+=1 
        
            
                
    
 
    return result_dict

