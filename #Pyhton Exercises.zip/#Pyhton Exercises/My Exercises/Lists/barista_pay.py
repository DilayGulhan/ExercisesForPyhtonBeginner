#This program show how to use list in calculations
NUM_EMPLOYEES = 6

def main():
    hours =[0] * NUM_EMPLOYEES 
    for index in range(NUM_EMPLOYEES):
        hours[index] =  float(input(""))

    hourly_pay_rate = float(input("Enter the hourly pay rate"))
    for index in range(NUM_EMPLOYEES) : 
        gross_pay = hours[index] * hourly_pay_rate
        print(gross_pay)
main()

#Come back this question 

        
