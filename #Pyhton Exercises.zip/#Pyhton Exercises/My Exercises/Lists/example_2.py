#Lists in pyhton can be changed
numbers = [1 ,2 ,3 ,4]
print(numbers)
numbers[0 ] = 99 
print(numbers)

"""numbers_2 = [1 ,2 ,3 ,4 ,5]
numbers_2 [5] = 99 "" it gonna be an index error""
print(numbers_2)"""

num = [0] * 5 #Create a list with 5 elements 
#Fill the list with value 99 
index = 0 
while index < len(num):
    num[index] = 99 
    index += 1 
print(num)

#Concatenating lists
list1 = [1,2,3,4]
list2 = [5,6,7,8]
list3 = list1 + list2
print(list3)

girl_names=["Erica" , "Joanna", "Karen"]

boys_names = ["Sam" , "Alex" , "Smith"]

all_names = girl_names + boys_names
print(all_names)

#Another Example 
list5 = [1 , 2 ,3 ,4 ,5 ]
list6 = [6 ,7 ,8 ,9 ]
list5 += list6
print(list5)



