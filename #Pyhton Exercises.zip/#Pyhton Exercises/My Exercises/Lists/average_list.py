#This program calculates the average value of the list

def main():
    scores = [2.5 , 7.3 , 8.4 , 4.0]
    total = 0.0 #Accumulator
    for value in scores:
        total = total + value
    average = total / len(scores)
    print(average)
main()