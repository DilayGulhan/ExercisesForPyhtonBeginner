#This program uses a function to calculate 
# the total of the values in a list

from typing import Mapping


def main():
    #Create a list 
    numbers = [2 ,4 ,6 ,8 ,10]
    print("The total is" , get_total(numbers))

def get_total(value_list):
    total = 0 

    for num in value_list:
        total += num 
    return total

main()

