#In this code we will find the most repeated number in the list.

list = ["a " , "b", "a" , "c" , "d", "c" , "a", "b", "b" , "b" , "d"]

for x in ["a" , "b" , "c", "d"] :
    item = x 
    repeat = 0 
    for i in range(len(list)):
        if list[i] == item:
            repeat +=1 
    print(item , repeat)