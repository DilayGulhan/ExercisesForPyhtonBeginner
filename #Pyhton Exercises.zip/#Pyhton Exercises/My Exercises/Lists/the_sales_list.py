#The Num_Days constant hold the number of 
# days that we will gather sales data for. 
Num_Days = 5

def main():
    sales = [0] * Num_Days
    index = 0 
    print("Enter the Sales for each day ")

    while index < Num_Days:
        sales[index] = float(input())
        index += 1 
    for value in sales :
        print(value)
    
main()