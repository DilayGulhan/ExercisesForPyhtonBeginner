#LIST SLICING
#For in list name[start:end] but not including end

days = ["Sunday " , "Monday " , "Tuesday" , "Wednesday" , "Thursday" , "Friday" , "Saturday"]
mid_days = days[2 : 5]
print(mid_days)

numbers = [ 1 ,2 ,3 ,4, 5 ,6, 7, 8, 9,]

a = numbers[2 : ] #Two has included
b = numbers [:3] #Three hasn't included
d = numbers[ - 5]
print(a)
print(b)
print(d)

numbers3 = [1 , 2 ,3, 4, 5, 6, 7 , 8 , 9]
c = numbers3[1 : 8 : 2]
print(c)

