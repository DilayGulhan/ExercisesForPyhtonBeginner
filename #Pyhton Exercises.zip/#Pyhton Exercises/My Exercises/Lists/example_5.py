#APPEND METHOD IN THE LIST

def main():
    name_list = []

    again = "y"

    while again == "y":
        name = input("Enter a name:")

        name_list.append(name)  #Be careful in there because name is in () append is a function about lists 

        print("Do you want add another name")

        again = input("Enter y or n ")

        print()

        print("Here the names you entered")

    for name in name_list :
        print(name)
    
main()
        

