scores = [54.3 , 76.7 , 34.1 , 45 , 89 ,67.9]
maximum = 0 
for num in scores:
    if num > maximum:
        maximum = num
print(maximum)

for i in range(6) :
    if scores[i] > maximum:
         maximum = scores[i] 
print("The max number is :" , maximum)
