#THE REVERSE METHOD
my_list = [1 ,2, 3, 4, 5,]

print("Original order :" , my_list)

my_list.reverse()

print("Reversed:" , my_list)


#THE DEL STATEMENT

my_list_2 = [1 ,2 ,3 , 4 , 5]

print("before deletion " , my_list_2)

del my_list_2[2]

print("After deletion" , my_list_2)

#MIN AND MAX FUNCTIONS
my_list_3 = [1 ,-2 ,3 ,4 ,5 ,6, 7 , 50]
print ( "The lowest value is:" , min(my_list_3))

print("The highest value is :" ,max(my_list_3))
#COPYING LISTS

list1 = [1 ,2 ,3 ,4 ]
list2 = list1
print(list1)
print(list2)
list1[0] = 99 
print(list1)
print(list2)
#COPYING LISTS 2

list3 = [1 ,2 ,3, 4]
list5 = []

for item in list3:
    list5.append(item)
print(list5)

#COPYING LISTS 3
list6 = [1 ,2 ,3,4 ]
list7 = [] + list6 