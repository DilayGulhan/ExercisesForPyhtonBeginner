# This program demonstrates the insert method.
def main():
    names = ["James", "Kathryn" , "Bill"]

    print("The list before insert:")
    print("names")

    names.insert(0 , "Joe")

    print("The list after the insert:")
    print(names)

main()