#In this code we find same variables in two different lists
#We will add this variables to the new list

l1 = [3,5,6,7,9,11]
l2 = [1,2,3,6,8,9,14]
l3 = []
for item in l1:
    if item in l2 :
        l3.append(item)
print(l3)