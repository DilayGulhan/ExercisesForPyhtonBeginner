def main():
   scores = get_scores()
   total = get_total(scores)
   lowest= min(scores)
   total -= lowest
   average = total / (len(scores)-1)
   print("The average score is :" , average)

def get_scores():
    again= "y"
    while again== "y":
        my_score_list = []
        value = float(input("Enter the scores"))
        my_score_list.append(value)
        again = input("Do you want to continiue enter y or n  ")
    return my_score_list

def get_total(value_list):
    total_1 = 0.0
    for num in value_list:
        total_1 += num
        return total_1
main()
        

    






    



