numbers = list(range(5))
print(numbers)

numbers2 = list(range(1 ,10 , 2))
print(numbers2)

#The list can hold different type of items ! 
info = ["Adriana", True , 27 , 1550.80]

#The repetition operator 
repeat_zero  = [0] * 5 
print(repeat_zero) 

repeat_numbers = [1 ,2 ,3] * 4 
print(repeat_numbers)


#Iteraring over a list with a for loop

iteration_list = [99,100, 101 ,102]
for n in iteration_list :
    print(n)

#INDEXING
my_list = [10 ,20 ,30 ,40 ]
print(my_list[0] , my_list[1] , my_list[2] , my_list[3] )

index = 0 
while index< 4 :
    print(my_list[index])
    index += 1

#The len function 

size = len (my_list)
print(size )

#The len function also can be used to prevent an  
# IndexError exception when iterating  over a list with a loop
index = 0 
while index < len(my_list) :
    print(my_list[index])
    index += 1 





