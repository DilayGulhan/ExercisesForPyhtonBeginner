#INDEX METHOD TO CHANGE SOMETHING IN THE LIST

def main():
    food = ["Pizza" , "Burger" , "Chips" ]

    print("Here are the items in the food list :")

    print(food)
   

    item =input("Which item should I change")
    
    try: 
        item_index = food.index(item)
        new_item = input("Enter the new value")

        food[item_index] = new_item

        print("Here is the revised list:")
        print("Food ")
    except ValueError:
        print("That item wasn't found in list")

main()



    

    

