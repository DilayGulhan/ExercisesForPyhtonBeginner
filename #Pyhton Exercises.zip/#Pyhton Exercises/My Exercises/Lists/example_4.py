#FINDING ITEMS IN THE LIST WITH "IN" OPERATOR

def main():
    prod_numbers = ['V475', 'F987', 'Q143', 'R688']
    search = input("Enter the product number")
    if search in prod_numbers:        
        print(search, 'was found in the list.')
    else:        
        print(search, 'was not found in the list.')
main()



