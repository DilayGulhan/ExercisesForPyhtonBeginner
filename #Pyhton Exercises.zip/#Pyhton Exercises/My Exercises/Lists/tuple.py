list = [(1,3),(2,4,5,6),(7,8,9)]
result_list = []
for tup in list:
    result_list.append(tup[-1])
print(result_list)
#Tuple is faster than list 
