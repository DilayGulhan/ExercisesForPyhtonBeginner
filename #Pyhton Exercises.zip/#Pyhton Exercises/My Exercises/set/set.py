#Elemanları sıralı değil. 
#Elemanları için index tutmaz 
#Bir elemanı birden fazla tutmaz sadece bir kere tutar


fruits = {"banana", "grape", "cherry"}
print(fruits)

a = {1, 2, 3 , 5 , 4 , 7 , 4}
for item in a:
    print(item)

fruits.add("orange")
print(fruits)

fruits.update(["cherry ", " strawberry" , "melon"])
print(fruits)
 
a.remove(4) #x elemanı yoksa hata verir

a.discard(12) #x elemanı yoksa hata vermez

a.pop() #son elemanı siler sıralı olmadığı için hangisi silnidiği bilinmiyor

print(a)

#iki set birbibirne union ve update metodu ile bağlanabilir 
set1 = {1 ,2 ,3}
set2 = {"a" , "b" , "c"}

set1.union(set2)
print(set1)

set1.update(set2)
print(set1)
len(set1) #length of the set

if "x" in set1:
    print("yes")
else:
    print("no")
