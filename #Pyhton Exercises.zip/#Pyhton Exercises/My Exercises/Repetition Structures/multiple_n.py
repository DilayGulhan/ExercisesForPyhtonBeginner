#Ask the user for a number then multiply it 1 to n 

number = int(input("Enter a number"))