names = ["deniz" , " ilkay" , "irfan" , "ilker", "inanç" ]
total = 0
number = [1,6]
for a in number:
    total += number
    print(total)

