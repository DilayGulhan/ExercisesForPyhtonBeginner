def main():
    read_file = open("climate_types.txt" , "r")
    file_contents = read_file.read()
    read_file.close()
    print(file_contents)
main()

