def main():
    my_file = open("climate_types.txt" , "w")
    my_file.write("Tropical \n")
    my_file.write("Dry \n")
    my_file.write("Temperate \n")
    my_file.write("Continental \n")
    my_file.write("Polar \n")
    my_file.close()
main()

