#This program reads all of the values 
# in the sales.txt file
from typing import Counter


def main():
    #Open the sales.txt file for writing
    num_days = int(input("For how many days do you have sales"))
    #open a file name sales.txt
    sales_file = open("sales.txt" , "w")
    for count in range(1 , num_days+1):
        sales = float(input("Enter the sales for day ") )
        sales_file.write(str(sales) + "\n")

    sales_file.close()
    print("Data written to sales.txt:")
main()

