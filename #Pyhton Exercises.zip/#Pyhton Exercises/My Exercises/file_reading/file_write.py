#This program write three lines of data
# Open a file named philosophers.txt.
def main():
    outfile = open('philosophers.txt', 'w')
    outfile.write('John Locke\n')
    outfile.write('David Hume\n')
    outfile.write('Edmund Burke\n')
    outfile.write('Platon \n')
    outfile.close()
main()

