# "r" = open files for only reading. 
# -This file cannot be changed.
# "w" = open file for writing. 
# -If the file already exists, erase its contents. If it doesn't exist create it.
# "a" = open a file for written to.
# All data written to the file will be appended to its end. If the file does not exist, create it.