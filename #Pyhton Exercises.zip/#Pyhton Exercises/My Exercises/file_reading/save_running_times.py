"""Kevin is a freelance video producer who makes TV commercials for local businesses. When
he makes a commercial, he usually films several short videos. Later, he puts these short
videos together to make the final commercial. He has asked you to write the following two
programs."""
#1. A program that allows him to enter the running time (in seconds) of each short video
#in a project. The running times are saved to a file.
#2. A program that reads the contents of the file, displays the running times, and then
#displays the total running time of all the segments.
#Here is the general algorithm for the first program, in pseudocode:
#Get the number of videos in the project.
#Open an output file.
#For each video in the project:
#Get the video’s running time.
#Write the running time to the file.
#Close the file.

def main():
    num_videos = int(input("How many videos are there in the project"))

    video_file = open("video_times.txt" , "w")
    print("Enter the runnning times for each video")
    for count in range(1 , num_videos+1):
        run_time = float(input('Video #' + str(count) + ': '))
        video_file.write(str(run_time) + '\n')

    video_file.close()
    print('The times have been saved to video_times.txt.')
main()