#This program gets three names from the user 
# and write them to a file
def main():
    #Get three names
    print("Enter the name of three friends")
    name1 = input("Enter the first name")
    name2 = input("Enter the second name")
    name3 = input("Enter the third name")

    #Open a file named friends.txt 
    my_file = open("friends.txt" , "w")
    my_file.write(name1 + "\n")
    my_file.write(name2 + "\n")
    my_file.write(name3 + "\n")

    #close file
    my_file.close()
    print("The names were written to friends.txt")

main()



