def main():
    cluster()
    

def cluster():
    my_list = []
    determine = "y"
    while determine == "y" :
        number = int(input("Enter the numbers that you want to take to the list"))
        my_list.append(number)
        determine=input("Do you want to continiue to add number to your list press y or n ")
    my_list.sort()
    new_list = []
    for i in range(len(my_list)):
        for j in range(len(my_list)):
            if my_list[j]* 2 > my_list[i]:
                new_list.append([my_list[j]])
    
main()


        
            
          
        



    



    









         

        
       

         

            

        


   


