def main():
    take_grades()
    average()
def take_grades():
    student = "y"
    my_list = []
    while student == "y":
        mid_1 = int(input("Enter the mid 1 grade"))
        mid_2 = int(input("Enter the mid 2 grade"))
        final = int(input("Enter the final exam grades"))
        my_list.append([mid_1 , mid_2 , final])
        student= input("Do you want to add more student grades y or n ")
       
def average():
    
  






        

