import random
import math

def get_random_sqrt(matrix):
    i = random.randint(0, len(matrix)-1)
    j = random.randint(0, len(matrix[i])-1)
    n = matrix[i][j]
    return n, math.sqrt(n)

def main():
    random.seed(2021)
    M = [[9, 16, 25], [36, 49, 64]]
    n, sqrtn = get_random_sqrt(M)
    print(n, sqrtn)

if __name__ == "__main__":
    main()

