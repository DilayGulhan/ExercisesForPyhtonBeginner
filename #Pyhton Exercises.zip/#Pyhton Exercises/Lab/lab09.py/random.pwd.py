import random
import string
import time

def generate_random_pwd(level):
    lower = string.ascii_lowercase
    upper = string.ascii_uppercase
    num = string.digits
    symbols = string.punctuation

    if level == 1:
        pwd = random.choices(num, k=4)
    elif level == 2:
        pwd = random.choices((lower + num), k=8)
    elif level == 3:
        pwd = random.choices((lower + upper + num + symbols), k=16)
    else:
        pwd = ""
    print("".join(pwd))

def main():
    while(True):
        level = int(input("Security Level? "))
        if level == 0:
            break
        generate_random_pwd(level)

if __name__ == "__main__":
    main()