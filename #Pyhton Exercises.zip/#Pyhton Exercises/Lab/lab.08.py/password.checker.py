def main():
    password = input(  "password:")
    if len(password)< 8 or password.find("") == -1:
        print("level 0 ")
    elif password.isdigit() == True:
        print("level1")
    elif password.isalpha() == True :
        print("level1")
    elif password.isalnum() == True :
        print("Level2")
    else:
        print("Level 3")
    main()
    