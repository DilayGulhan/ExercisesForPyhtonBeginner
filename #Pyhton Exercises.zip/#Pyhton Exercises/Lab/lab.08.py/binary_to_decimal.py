def main():
    a = list_primes()
    b =compute_sum(a)
    print(b)

def list_primes(value):
    my_list = []
    for value in range(2000000):
        for i in range(value):
            if value% i != 0 :
                my_list.append[value]
                return my_list

def compute_sum(list1):
    total = 0 
    total += list1





    


            

    