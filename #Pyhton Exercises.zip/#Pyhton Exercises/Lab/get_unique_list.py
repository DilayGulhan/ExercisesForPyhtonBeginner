
def get_unique_list(L):
    UL = []
    for elem in L:
        if elem not in UL:
            UL += [elem]  # or UL.append(elem)
    return UL

def swap(L, i, j):
    L[i], L[j] = L[j], L[i]
    return L

def get_sorted_list(L):
    for i in range(len(L)):
        for j in range(i, len(L)):
            if L[i] > L[j]:
                L = swap(L, i, j)
    return L

def main():
    L = [5,2,1,1,2,4,3,5]
    UL = get_unique_list(L)
    SUL = get_sorted_list(UL)
    print(SUL)

if __name__ == "__main__":
    main()