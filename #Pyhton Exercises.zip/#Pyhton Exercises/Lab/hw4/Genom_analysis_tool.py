
def read_genes(file_path):
    gene_dict = {}
    count = 0
    with open(file_path) as f: 
        content = f.readlines() #Open folder
        for i in content:
            if len(content) > count: #We find header and sequence from this way 
                if count % 2 == 0:#If the order number is even this gonna be header 
                    header = i
                    count += 1
                    continue
                if count % 2 == 1: #If the order number is odd this gonna be sequence 
                    sequence = i
                    gene_dict[header] = sequence
                    count += 1
                    continue
    return gene_dict
    # STEP 1


def get_fragments(gene_dict, frag_len=50):
    frag_dict = {}
    for key, value in gene_dict.items():
        if len(value) >= frag_len:
            value1 = []
            while True:
                value1.append(value[0:frag_len])
                value = value[frag_len:]
                if len(value) < frag_len:
                    break

            key1 = key.split("|")
            chr_ = key1[0]
            key11 = key1[1].split("-")
            n_keys1 = int(key11[0])
            n_keys2 = int(key11[1])
            n = 0
            while ((n_keys2 - n_keys1)//frag_len) > 0:
                a = str(chr_) + "|" + str(n_keys1) + \
                    "-" + str(n_keys1+frag_len)
                b = value1[n]
                n += 1
                frag_dict[a] = b
                n_keys1 += frag_len
    return frag_dict
    # STEP 2



def filter_frags(frag_dict, threshold = 0.7):
    def get_similarity(s1, s2): 
        count = 0
        for i in range (len(s1)):
            if s2[i] == s1[i]:
                count += 1
        percentage = (count/len(s1))
        return percentage
    values=list(frag_dict.values())
    keys=list(frag_dict.keys())
    for i in range(len(values)):
        for j in range(i+1,len(values)):
            if get_similarity(values[i],values[j]) >= threshold:
                del frag_dict[keys[j]]
    dissimilar_frag_dict=frag_dict
    return dissimilar_frag_dict
        # Algoritma
        # Listeye çevir
    # İki listeyi karşılaştırmak için kopyala
    # Listeleri key_1 = 0 , key_2 =2 için aynı value değerleri için tara
    #
    # If else döngüsü yap
        # Dictionary'ye geri çevir


def get_sentences(dissimilar_frag_dict):
    sentence_dict = {}
    def generate_kmers(seq, k):
        if k <= seq:
            sentence = {}
            seq_value_l = list(seq.values())
            seq_key_l = list(seq.keys())
            first_value = 0
            second_value = k
        for key in seq_key_l:
            for i in range(seq//k):
                for i in range(k):
                    sentence_list = seq_value_l.append(i)
                    sentence_list.split[first_value: second_value]
                    sentence[key] = sentence_list
                    first_value += 1
                    second_value += 1
                    return sentence
        else:
            print("You can't split the bigger number from sequence")

    for key, value in dissimilar_frag_dict.items():
        int = generate_kmers(value, 4)
        sentence_dict[key] = int
        return sentence_dict

    # Algoritma
    # Dictionary ama üstteki list metodu ona göre implement etmen gerek


def clean_dict(sentences_dict):

    def clean_sentence(sentence):
        values = sentence.split()
        sentencestr = ""
        for i in values:
            if i not in sentencestr:
                sentencestr += i + " "
        return sentencestr.strip()
    clean_dictnry = {}
    for key, value in sentences_dict.items():
        newvalue = clean_sentence(value)
        clean_dictnry[key] = newvalue
    return clean_dictnry


def write_genes(file_path, clean_sentences_dict):
    # STEP 6
    import csv
    with open(file_path, 'w', encoding='UTF8', newline="") as f:
        writer = csv.writer(f)
        header_names = ["fragment_id", "sentence",
                        "sentence_length", "number_of_words"]
        writer.writerow(header_names)
        for key, value in clean_sentences_dict.items():
            calculator = value.split()
            number_of_words = len(calculator)
            length = len(value)
            rows = [key, value, str(length), str(number_of_words)]
            writer.writerow(rows)


def main():
    gene_dict = read_genes('hw4/input.txt')
    print("the number of genes:", len(gene_dict))
    # 2
    frag_dict = get_fragments(gene_dict) 
    print("the number of fragments:", len(frag_dict))
    # 3
    dissimilar_frag_dict = filter_frags(frag_dict)
    print("the number of dissimilar fragments:", len(dissimilar_frag_dict))
    

if __name__ == "__main__":
    # STEP 7: Runs required steps and prints data statistics

    # 1) read genes from input.txt
    #    print the number of genes -> Expected output: 115
    # 2) get fragments for genes read
    #    print the number of fragments -> Expected output: 1293
    # 3) filter out similar fragments
    #    print the number of dissimilar fragments -> Expected output: 1286
    # 4) get sentences for dissimilar fragments
    #    print the number of words in a sentence -> Expected output: 46
    # 5) remove duplicate words in sentences
    #    print the total number of words removed -> Expected output: 8194
    # 6) write sentences into output.csv
    main()
