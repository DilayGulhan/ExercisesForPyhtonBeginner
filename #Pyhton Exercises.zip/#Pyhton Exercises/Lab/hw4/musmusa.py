
def get_fragments(gene_dict, frag_len=50): 
    frag_dict = {} #We create empty dictionary to write the items
    for key, value in gene_dict.items(): #Both we get key and items with use this method
        if len(value) >= frag_len:
            value1 = [] #The empty list to append values
            while True: 
                value1.append(value[0:frag_len]) #We split it to the 50 frags
                value = value[frag_len:] 
                if len(value) < frag_len:
                    break

            key1 = key.split("|")
            chr_ = key1[0]
            key11 = key1[1].split("-")
            n_keys1 = int(key11[0])
            n_keys2 = int(key11[1])
            n = 0
            while ((n_keys2 - n_keys1)//frag_len) > 0:
                a = str(chr_) + "|" + str(n_keys1) + \
                    "-" + str(n_keys1+frag_len)
                b = value1[n]
                n += 1
                frag_dict[a] = b
                n_keys1 += frag_len
    return frag_dict