dictionary =  {"chr1|55555000-55555010" : "CTGCATCAAG" , "chr1|55555010-55555020" : "CTGTATCAAT"}
def filter_frags(frag_dict, threshold = 0.7):
    def get_similarity(s1, s2): 
        count = 0
        for i in range (len(s1)):
            if s2[i] == s1[i]:
                count += 1
        percentage = (count/len(s1))
        return percentage
    values=list(frag_dict.values())
    keys=list(frag_dict.keys())
    for i in range(len(values)):
        for j in range(i+1,len(values)):
            if get_similarity(values[i],values[j]) >= threshold:
                del frag_dict[keys[j]]
    dissimilar_frag_dict=frag_dict
    return dissimilar_frag_dict
        # Algoritma
        # Listeye çevir
    # İki listeyi karşılaştırmak için kopyala
    # Listeleri key_1 = 0 , key_2 =2 için aynı value değerleri için tara
    #
    # If else döngüsü yap
        # Dictionary'ye geri çevir


def get_sentences(dissimilar_frag_dict):
    sentence_dict = {}
    def generate_kmers(seq, k):
        if k <= seq:
            sentence = {}
            seq_value_l = list(seq.values())
            seq_key_l = list(seq.keys())
            first_value = 0
            second_value = k
        for key in seq_key_l:
            for i in range(seq//k):
                for i in range(k):
                    sentence_list = seq_value_l.append(i)
                    sentence_list.split[first_value: second_value]
                    sentence[key] = sentence_list
                    first_value += 1
                    second_value += 1
                    return sentence
        else:
            print("You can't split the bigger number from sequence")

    for key, value in dissimilar_frag_dict.items():
        int = generate_kmers(value, 4)
        sentence_dict[key] = int
        return sentence_dict
main()