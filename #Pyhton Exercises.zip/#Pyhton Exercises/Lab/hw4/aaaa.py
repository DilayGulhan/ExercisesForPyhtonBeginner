
def filter_frags(frag_dict, threshold=0.7):

    def get_similarity(s1, s2):
        # STEP 3.a
        count = 0

        for i in len(s1):
            if s2[i] == s1[i]:
                count += 1

        percentage = (count//len(s1))
        return percentage

    frag_dict_2 = frag_dict.copy()  # Kopyasını aldım çünkğ ondan çıkartacağım

    

    count= 0
    integer = 1
    key_l_2 = list(frag_dict_2.keys())
    value_l_2 = list(frag_dict_2.values())
    key_l = list(frag_dict_2.keys())
    value_l = list(frag_dict_2.values())
    new_list_for_dissim = []
    percent = get_similarity()
    dissimilar_frag_dict = {}
    if percent > threshold:

        key_for_1 = key_l[count:]
        key_for_2 = key_l_2[integer:]
        for i in key_for_1:
            for i in value_l:
                for i in key_for_2:
                    for i in value_l_2:
                        if value_l[i] != value_l_2[i]:
                            dissimilar = new_list_for_dissim.append[i]
                            dissimilar_frag_dict[key_for_1] = dissimilar
        return dissimilar_frag_dict

