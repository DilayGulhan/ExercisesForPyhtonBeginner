num1 = -79/2
num2 = 33/2
num3 = -59/4
num4 = 114 
num5 = -91/2
num6 = 83/2
num7 = 471/2
num8 = -96
num9 = 347/4

a = float(input(" Enter the num 1" ))
b = float(input(" Enter the num 2" ))
c = float(input(" Enter the num 3" ))
x= num1*a + num2*b + num3* c
y = num4*a + num5 * b + num6 * c 
z = num7*a + num8 * b + num9 * c 
print (x )
print(y)
print(z)
