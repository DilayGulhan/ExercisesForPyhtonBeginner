def unique_list(numbers):
    return list(set(numbers))

def unique_elements(numbers):
    elements



numbers1 = [2, 3, 4, 20, 5, 5, 15]
numbers_2 = [10, 20, 20 15, 30 40]
 
